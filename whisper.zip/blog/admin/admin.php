<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<style>
a{
    text-decoration: none;
}

    button{
        cursor: pointer;
        padding: 10px 20px;
    background: #4e67f5;
    color: white;
    border: none;
    margin-bottom: 3vh;
    font-size: 16px;
    border-radius: 5px;
    width: 25vw;
    }

    img{
    width: 30vw;
   margin-bottom: 10vh;
   margin-top: 10vh;
    }
</style>
<body>


<div style="display: flex;
    flex-direction: column;
    /* height: 50vh; */
    align-items: center;">
<img src="../../images/logo.svg" alt="">

<a href="../blog.php">
        <button >Blog </button>
    </a>



    <a href="new-post.php">
        <button >Agregar post</button>
    </a>

    <a href="new-video-post.php">
    <button >Agregar video post</button>
    </a>
    

</div>








</body>
</html>